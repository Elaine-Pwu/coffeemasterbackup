package Process;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.ArrayList;

import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Servlet implementation class Integration
 */
@WebServlet("/Intergation")
public class Integration extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	public ArrayList<WebPage>page=new ArrayList<WebPage>();
	public ArrayList<WebNode>node=new ArrayList<WebNode>();
	public KeywordList key;
	
    public Integration() {
        super();
    }

    public static void main(String[] arg) {
    	KeywordList key=new KeywordList();
    	try{
			File input = new File("pro_input.txt");
			Scanner read = new Scanner(input);
			while(read.hasNextLine()) {
				String inputkey=read.next();
				double value = (double)read.nextInt();
				Keyword keyword= new Keyword(inputkey, value);
				key.add(keyword);
				System.out.print(keyword.getName());
				System.out.println();
			}
			read.close();
		}catch(FileNotFoundException e) {
//			System.out.println("pro_input.txt Not Found");
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.setCharacterEncoding("UTF-8");
//		request.setCharacterEncoding("UTF-8");
//		response.setContentType("text/htm");
//		if(request.getParameter("inputKeyword")== null) {
//			String requestUri = request.getRequestURI();
//			request.setAttribute("requestUri", requestUri);
//			request.getRequestDispatcher("Search.jsp").forward(request, response);
//			return;
//		}
//		GoogleQuery google = new GoogleQuery(request.getParameter("inputKeyword"));
////		HashMap<String, String> query = google.query();
//
////		HashMap<String, String> result = g.query();
//		HashMap<String, String> result = google.query();
//		QuickSort q = new QuickSort();
//		for (String key : result.keySet()) {
//			q.add(new WebNode(new WebPage(key, result.get(key))));
//		}
//
//		q.sort();
//		String[][] r = q.output();
//		
//		System.out.println(r.length);
//		request.setAttribute("query", r);
////		int num = 0;
////		for(Entry<String, String> entry : result.entrySet()) {
////		    String key = entry.getKey();
////		    String value = entry.getValue();
////		    s[num][0] = key;
////		    s[num][1] = value;
////		    
////		    
////		    page.add(new WebPage(key,value));
////		    
////		    num++;
////		}
////		
////		
////		
////	    for(int i =0;i<page.size();i++) {
////	    	node.set(i,new WebNode((WebPage)page.get(i)));
////	    }
////	    
////	    QuickSort sort=new QuickSort();
////	    for(int j =0;j<node.size();j++) {
////	    	sort.add((WebNode)node.get(j));
////	    }
////	    
////	    for(int j=1;j<node.size();j++) {
////	    	node.get(0).addChild(node.get(j));
////	    	node.get(j).parent=node.get(0);
////	    }
////	    WebTree tree=new WebTree(page.get(0));
////		
//////(keyword?)	    tree.setPostOrderScore(key);
////	    tree.eularPrintTree();
//		
//	
//		request.getRequestDispatcher("SearchResult.jsp").forward(request, response); 
//		
//	}
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		if(request.getParameter("inputKeyword")== null) {
			String requestUri = request.getRequestURI();
			request.setAttribute("requestUri", requestUri);
			request.getRequestDispatcher("Search.jsp").forward(request, response);
			return;
		}
		GoogleQuery google = new GoogleQuery(request.getParameter("inputKeyword"));
		HashMap<String, String> query = google.query();
//		ArrayList<String> relativelist = FindRelativeKeywords();
//		HashMap<String, String> relate = google.relate(request.getParameter("keyword"));
		HashMap<String, String> relate = google.relate();
//		for (Double b : retVal) {
//			System.out.println(b);
//		}


		
		
		
		
		
//		key = new KeywordList();
//		try{
//			File input = new File("pro_input.txt");
//			Scanner read = new Scanner(input);
//			while(read.hasNextLine()) {
//				String inputkey=read.next();
//				double value = (double)read.nextInt();
//				Keyword keyword= new Keyword(inputkey, value);
//				key.add(keyword);
//			}
//			read.close();
//		}catch(FileNotFoundException e) {
//			System.out.println("pro_input.txt Not Found");
//			e.printStackTrace();
//		}catch(IOException e) {
//			e.printStackTrace();
//		}
		
		QuickSort q = new QuickSort();
		for (String key : query.keySet()) {
			String url = query.get(key);
			int trash = url.indexOf("&sa");
			if(trash != -1) {
				url = url.substring(0, trash);
			}
			q.add(new WebNode(new WebPage(key, url)));
		}
		

		q.sort();
		String[][] s = q.output();
		
//		String[][] s = new String[query.size()][2];
		request.setAttribute("query", s);
//		request.setAttribute("relative", ((GoogleQuery) google).FindRelativeKeywords());
//		request.setAttribute("relative", google.relativeLink);

//		String[][] r = new String[relate.size()][2];
//		String[][] r = q.output();
//		
//
//		request.setAttribute("relate", r);
		
//		int n = 0;
		QuickSort q2 = new QuickSort();
		for (String relateUrl:relate.keySet()) {
			String title = relateUrl;
//					relate.get(relateUrl);
			String url = relate.get(relateUrl);
//			int trash = url.indexOf("&sa");
//			if(trash != -1) {
//				url = url.substring(0, trash);
//			}

//			r[n][0] = title;
//			r[n][1] = url;
//			System.out.printf("related title:%s,url:%s\n", title, url);
//			n++;
			
			q2.add(new WebNode(new WebPage(relateUrl,url)));
			System.out.printf("related title:%s,url:%s\n", title, url);
			
		}
//		System.out.printf("related title:%s,url:%s\n", title, url);

		String[][] r = q2.output();
		

		request.setAttribute("relate", r);
//		request.getRequestDispatcher("resultPage.jsp").forward(request, response);

//		
//		
//		System.out.println(FindRelativeKeywords());
//		System.out.println(google.relativeLink);
//		System.out.print(relativelist);
//		
//		
//		
//		System.out.println("the first:" + s[0][0]);
//		System.out.println("the first:" + s[0][1]);
//		System.out.println("the second:" + s[1][0]);
//		System.out.println("the second:" + s[1][1]);
//		
		
//		int num = 0;
//		for(Entry<String, String> entry : query.entrySet()) {
//		    String key = entry.getKey();
//		    String value = entry.getValue();
//		    s[num][0] = key;
//		    s[num][1] = value;
//		    num++;
//		}
		request.getRequestDispatcher("SearchResult.jsp").forward(request, response); 
		
	}
    

//	public ArrayList<String> FindRelativeKeywords(){
//		ArrayList<String> relative = new ArrayList<String>();
////		String Input = searchKeyword;
//		try {
//			GoogleQuery gq = new GoogleQuery("inputKeyword");
//			Document doc = Jsoup.connect(gq.url).get();
//			Elements relativeLis = doc.body().getElementsByClass(".kJGX2");
//			
//			for(Element rel:relativeLis) {
//				String [] get = rel.getElementsByTag("div").text().split(" ");
//				String key = get[0].replaceAll(" ", " ");
//				if(!relative.contains(key)) {
//					relative.add(key);
//					if(relative.size()==4) {
//						return relative;
//					}
//				}
//			}
//		}catch(IOException e) {
//			
//		}
//		
//		return relative;
//	}
    

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}

