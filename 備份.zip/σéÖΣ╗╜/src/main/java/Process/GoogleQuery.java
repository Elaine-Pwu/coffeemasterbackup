package Process;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class GoogleQuery {
	public String searchKeyword;
	public String url;
	public String content;
	public String title;
	public String relativetitle;
	public String citeUrl;
	public String citeUrl2;
	public WordCounter counter;
	public WordCounter counter2;
	public ArrayList<String> relativeLink;
	
//	public static void main(String[] args) throws IOException {
//		GoogleQuery g = new GoogleQuery("貓");
//		HashMap<String, String> result = g.query();
//		QuickSort q = new QuickSort();
//		for (String key : result.keySet()) {
//			q.add(new WebNode(new WebPage(key, result.get(key))));
//		}
//
//		q.sort();
//		String[][] r = q.output();
//		System.out.print(r.length);
////		System.out.print(relativeLink);
////		System.out.println("the first:" + r[0][0]);
////		System.out.println("the first:" + r[0][1]);
////		System.out.println("the second:" + r[1][0]);
////
////		QuickSort quickSort = new QuickSort();
////		String[][] result_sorted = (String[][]) quickSort.output();
//		
//	}
	
	public GoogleQuery(String searchKeyword) {
//		this.searchKeyword = searchKeyword.concat("+coffee");
		this.url = "http://www.google.com/search?q="+searchKeyword+ "+cafe" +"&he=utf8&num=20";
		System.out.println(url);
	}
	
	private String fetchContent() throws IOException {
		String retVal = "";

		URL u = new URL(url);
		URLConnection conn = u.openConnection();
		//set HTTP header
		conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
		InputStream in = conn.getInputStream();

		InputStreamReader inReader = new InputStreamReader(in, "utf-8");
		BufferedReader bufReader = new BufferedReader(inReader);
		String line = null;

		while((line = bufReader.readLine()) != null) {
			retVal += line;
		}
		return retVal;
	}
	

	
	public HashMap<String, String> query() throws IOException {
		if(content == null) {
			content = fetchContent();
		}

		HashMap<String, String> retVal = new HashMap<String, String>();
		
		
		/* 
		 * some Jsoup source
		 * https://jsoup.org/apidocs/org/jsoup/nodes/package-summary.html
		 * https://www.1ju.org/jsoup/jsoup-quick-start
 		 */
		
		//using Jsoup analyze html string
		Document doc = Jsoup.parse(content);
		
		
		//select particular element(tag) which you want 
		Elements lis = doc.select("div");
		lis = lis.select(".kCrYT");
		
//		Elements lis2 = doc.select("div");
//		lis2 = lis2.select("span").select(".lRVwie");
//		relativeLink = new ArrayList<String>();
//		
//		for(Element ref : lis2) {
////			try {
//			relativeLink.add(ref.text());
////			citeUrl2 = ref.select("a").get(0).attr("href");
////			counter2 = new WordCounter(citeUrl2);
////			relativetitle = ref.select("a").get(0).select(".y6Uyqe").text();
////			if(relativetitle.equals("")) {
////				continue;
////			}
//			
////			System.out.println(ref.text());
////			System.out.println("rTitle: " + relativetitle + " , url: " + citeUrl2);
////			
////			//put title and pair into HashMap
////			retVal.put(relativetitle, citeUrl2);
////			}catch(IndexOutOfBoundsException e) {
////				
////			}
//		}
		
		
		
		for(Element li : lis) {
			
			try {
				citeUrl = li.select("a").get(0).attr("href");
				counter = new WordCounter(citeUrl);
				title = li.select("a").get(0).select(".vvjwJb").text();
				
				if(title.equals("")) {
					continue;
				}
				
				System.out.println("Title: " + title + " , url: " + citeUrl);
				
				//put title and pair into HashMap
				retVal.put(title, citeUrl);

			} catch (IndexOutOfBoundsException e) {
//				e.printStackTrace();
			}
		}
		return retVal;
	}
	
	
	public HashMap<String, String> relate() throws IOException {
		if(content == null) {
			content = fetchContent();
		}
//		
//		String[] splitStr = searchKeyword.split(" ");
//		if (splitStr.length > 1) {
//			String comb = "";
//			for (int i = 0; i < splitStr.length; i++) {
//				comb += splitStr[i] + "+";
//			}
//			searchKeyword = comb;
//		}
//		if (!searchKeyword.contains("cafe")) {
//			searchKeyword += "cafe";
//		}

//		String url = "http://www.google.com/search?q=" + searchKeyword + "&oe=utf8&num=20";
//		System.out.println("url: " + url);
		
		
		
		
		

		String content = fetchContent();
		HashMap<String, String> retVal = new HashMap<String, String>();

		// using Jsoup analyze html string
		Document doc = Jsoup.parse(content);

		// select particular element(tag) which you want
//		Elements lis = doc.select("a[class]");
//		lis = lis.select(".Q71vJc");

		Elements lis2 = doc.select("div");
		lis2 = lis2.select("span").select(".lRVwie");
//		y6Uyqe
//		Q71vJc
		
		for (Element li : lis2) {
			
			citeUrl2 = li.select("a").get(0).attr("href");
//			counter = new WordCounter(citeUrl);
			relativetitle = li.select("a").get(0).select(".s3v9rd").text();
			
//			relativetitle = li.select("a").get(0).select(".EIaa9b").text();

			
			
//			String citeUrl = li.attr("href");
//			citeUrl2 = li.attr("href");

//			String urlstr = URLDecoder.decode(citeUrl, "UTF-8");
////			title = li.select("a").get(0).select(".vvjwJb").text();
//
//			urlstr="http://www.google.com"+urlstr;
//			String urlStr2 = urlstr.text();
			//citeUrl.replaceAll(" ", "%20");
			
//			relativetitle = li.select(".s3v9rd").text();
			if (relativetitle.equals("")) {
				continue;
			}
//			System.out.print("related");
//			System.out.println("Title: " + title + " , url: " + urlstr);
			retVal.put(relativetitle, citeUrl2);	

		}
		return retVal;
	}
//	
//	public ArrayList<String> FindRelativeKeywords(){
//		ArrayList<String> relative = new ArrayList<String>();
////		String Input = searchKeyword;
//		try {
//			Document doc = Jsoup.connect(url).get();
//			Elements relativeLis = doc.body().getElementsByClass(".kJGX2");
//			
//			for(Element rel:relativeLis) {
//				String [] get = rel.getElementsByTag("div").text().split(" ");
//				String key = get[0].replaceAll(" ", " ");
//				if(!relative.contains(key)) {
//					relative.add(key);
//					if(relative.size()==4) {
//						return relative;
//					}
//				}
//			}
//		}catch(IOException e) {
//			
//		}
//		
//		return relative;
//	}
	
}