# Coffee Master
group 17<br>
[project proposal](https://docs.google.com/document/d/1Mo54w-9lO0IDJ0kDCCDQ8dzizOmQ1NsGlb9IUHwlHHQ/edit?usp=sharing)
